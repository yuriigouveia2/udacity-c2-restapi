"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = {
    "dev": {
        "username": "yuriigouveia",
        "password": "Simpsons007yuri",
        "database": "udagramyuridev",
        "host": "udagramyuridev.cis6odahbbfw.sa-east-1.rds.amazonaws.com",
        "dialect": "postgres",
        "aws_reigion": "sa-east-1",
        "aws_profile": "DEPLOYED",
        "aws_media_bucket": "udagram-yuri-dev",
    },
    "prod": {
        "username": "",
        "password": "",
        "database": "udagram_prod",
        "host": "",
        "dialect": "postgres"
    }
};
//# sourceMappingURL=config.js.map